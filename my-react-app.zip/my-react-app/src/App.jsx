import { useState } from 'react';
import './App.css';

function App() {
  const [quiz, setQuiz] = useState('');
  const [lab, setLab] = useState('');
  const [exam, setExam] = useState('');
  const [result, setResult] = useState(null);

  const calculateGrade = () => {
    const q = parseFloat(quiz);
    const l = parseFloat(lab);
    const e = parseFloat(exam);

    if (isNaN(q) || isNaN(l) || isNaN(e)) {
      alert('Please enter valid numeric grades.');
      return;
    }

    const overall = (q * 0.3) + (l * 0.3) + (e * 0.4);
    const gradePoint = getGradePoint(overall);

    setResult({
      overall: overall.toFixed(2),
      point: gradePoint.toFixed(2)
    });
  };

  const getGradePoint = (score) => {
    if (score <= 74.5) return 0;
    else if (score <= 76.5) return 1;
    else if (score <= 78.5) return 1.25;
    else if (score <= 80.5) return 1.5;
    else if (score <= 82.5) return 1.75;
    else if (score <= 84.5) return 2.0;
    else if (score <= 86.5) return 2.25;
    else if (score <= 88.5) return 2.5;
    else if (score <= 90.5) return 2.75;
    else if (score <= 92.5) return 3.0;
    else if (score <= 94.5) return 3.25;
    else if (score <= 96.5) return 3.5;
    else if (score <= 98.5) return 3.75;
    else return 4.0;
  };

  const handleLogout = () => {
    setQuiz('');
    setLab('');
    setExam('');
    setResult(null);
  };

  return (
    <div className="container">
      <h1>Grades Calculator</h1>

      <label>Quizzes</label>
      <input
        type="number"
        value={quiz}
        onChange={(e) => setQuiz(e.target.value)}
      />

      <label>Lab Activities</label>
      <input
        type="number"
        value={lab}
        onChange={(e) => setLab(e.target.value)}
      />

      <label>Final Exam</label>
      <input
        type="number"
        value={exam}
        onChange={(e) => setExam(e.target.value)}
      />

      <button className="submit-button" onClick={calculateGrade}>
        Submit
      </button>

      {result && (
        <div className="result">
          <p><strong>Grade:</strong> {result.overall}</p>
          <p><strong>Final Grade:</strong> {result.point}</p>
        </div>
      )}

      <button className="logout-button" onClick={handleLogout}>
        Logout
      </button>
    </div>
  );
}

export default App;
