// src/components/Login.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

// A mock array of user credentials
const predefinedUsers = [
    { username: 'user1', password: 'password1' },
    { username: 'admin', password: 'adminpassword' },
];

function Login({ onLoginSuccess }) {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (event) => {
        event.preventDefault();

        // Find a user that matches the entered credentials
        const user = predefinedUsers.find(
            (u) => u.username === username && u.password === password
        );

        if (user) {
            setError('');
            console.log('Login successful');
            onLoginSuccess(); // Notify the parent component (App.js)
            navigate('/home'); // Redirect to the home page
        } else {
            setError('Invalid username or password. Please try again.');
        }
    };

    return (
        <div className="login-container">
            <form onSubmit={handleSubmit} className="login-form">
                <h2>Login</h2>
                {error && <p className="error">{error}</p>}
                <div className="form-group">
                    <label htmlFor="username">Username</label>
                    <input
                        type="text"
                        id="username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <button type="submit">Login</button>
            </form>
        </div>
    );
}

export default Login;