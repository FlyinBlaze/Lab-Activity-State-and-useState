// src/components/About.js
import React from 'react';

function About() {
    return (
        <div className="page-content">
            <h1>About Us</h1>
            <p>This is a simple Single Page Application created with React and React Router.</p>
            <p>Our mission is to demonstrate the fundamentals of client-side routing in a modern web application.</p>
        </div>
    );
}

export default About;