// src/components/Contact.js
import React from 'react';

function Contact() {
    return (
        <div className="page-content">
            <h1>Contact Us</h1>
            <p>If you have any questions, feel free to reach out!</p>
            <ul>
                <li>Email: contact@react-spa.com</li>
                <li>Phone: (123) 456-7890</li>
            </ul>
        </div>
    );
}

export default Contact;