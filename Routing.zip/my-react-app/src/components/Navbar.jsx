// src/components/Navbar.js
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

function Navbar({ onLogout }) {
    const navigate = useNavigate();

    const handleLogoutClick = () => {
        onLogout(); // Update the login state in App.js
        navigate('/'); // Navigate to the login page
    };

    return (
        <nav className="navbar">
            <div className="nav-brand">
                <Link to="/home">React SPA</Link>
            </div>
            <ul className="nav-links">
                <li><Link to="/home">Home</Link></li>
                <li><Link to="/about">About Us</Link></li>
                <li><Link to="/contact">Contact Us</Link></li>
            </ul>
            <button onClick={handleLogoutClick} className="logout-button">
                Logout
            </button>
        </nav>
    );
}

export default Navbar;