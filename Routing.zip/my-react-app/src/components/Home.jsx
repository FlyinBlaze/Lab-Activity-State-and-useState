// src/components/Home.js
import React from 'react';

function Home() {
    return (
        <div className="page-content">
            <h1>Welcome to the Home Page!</h1>
            <p>You have successfully logged in. You can now navigate to other pages.</p>
        </div>
    );
}

export default Home;