// src/App.jsx
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Login from './components/Login.jsx';
import Home from './components/Home.jsx';
import About from './components/About.jsx';
import Contact from './components/Contact.jsx';
import Navbar from './components/Navbar.jsx';
import './App.css';

function AppContent() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const location = useLocation();
    const mainClassName = location.pathname === '/' ? 'main-login' : 'main-content';

    const handleLogin = () => setIsLoggedIn(true);
    const handleLogout = () => setIsLoggedIn(false);

    return (
        <div className="App">
            {isLoggedIn && <Navbar onLogout={handleLogout} />}
            <main className={mainClassName}>
                <Routes>
                    <Route path="/" element={!isLoggedIn ? <Login onLoginSuccess={handleLogin} /> : <Navigate to="/home" />} />
                    <Route path="/home" element={isLoggedIn ? <Home /> : <Navigate to="/" />} />
                    <Route path="/about" element={isLoggedIn ? <About /> : <Navigate to="/" />} />
                    <Route path="/contact" element={isLoggedIn ? <Contact /> : <Navigate to="/" />} />
                    <Route path="*" element={<Navigate to={isLoggedIn ? '/home' : '/'} />} />
                </Routes>
            </main>
        </div>
    );
}

function App() {
    return (
        <Router>
            <AppContent />
        </Router>
    );
}

export default App;